package com.example.rimo_chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
